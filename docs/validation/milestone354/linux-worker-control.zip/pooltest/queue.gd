extends SceneTree

func _initialize() -> void:
	var wait_msec := 200
	for i in 8:
		WorkerThreadPool.add_task(Callable(OS, "delay_msec").bind(wait_msec), false, "bounded native work")
	print("[worker-shutdown] eight finite native tasks submitted")
	quit()
