extends SceneTree
func _initialize() -> void:
	var project := ProjectSettings.globalize_path("res://")
	var cache := "user://empty-classes.cfg"
	var config := ConfigFile.new()
	config.set_value("", "list", [])
	assert(config.save(cache) == OK)
	var pack := PCKPacker.new()
	assert(pack.pck_start(OS.get_cmdline_user_args()[0]) == OK)
	assert(pack.add_file("res://project.godot", project.path_join("project.godot")) == OK)
	assert(pack.add_file("res://.godot/global_script_class_cache.cfg", ProjectSettings.globalize_path(cache)) == OK)
	assert(pack.flush() == OK)
	quit()
