extends "res://scripts/diagnostics/integration_benchmark.gd"

func run() -> void:
	suite = "environment"
	timeline = TIMELINE.new()
	root.add_child(timeline)
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	Engine.max_fps = 0
	game = load("res://scenes/missions/harlow_escape.tscn").instantiate()
	root.add_child(game)
	await ready_render()
	if game.graphics.current_index != 1:
		game.graphics.set_preset(1)
		await ready_render()
	journey = game.journey
	fog = game.fog_system
	game.player.input.scripted = true
	for actor: Node in [game.player, game.train, journey, fog, game.camera_rig]:
		actor.set_physics_process(false)
	game.camera_rig.exploration.set_process(false)
	for trigger in game.find_children("*", "CutawayTrigger", true, false):
		trigger.set_deferred("monitoring", false)
	eye = Camera3D.new()
	eye.fov = 78
	eye.near = 0.06
	eye.far = 350
	game.add_child(eye)
	eye.make_current()
	RenderingServer.viewport_set_measure_render_time(root.get_viewport_rid(), true)
	var corridor: Node3D = game.get_node("RouteTrack")
	var main_line: Node3D = game.station.get_node("MainLine")
	var masonry := game.find_children("MasonryInnerLeaf", "MeshInstance3D", true, false)
	var groups := {"corridor hidden": [corridor], "running line hidden": [main_line], "inner brick leaves hidden": masonry}
	var paths := {}
	for title in groups:
		paths[title] = []
		for item: Node3D in groups[title]:
			paths[title].append(str(item.get_path()))
	var fixtures := ["Warehouse B", "Locomotive cab", "Passenger car"]
	for i in fixtures.size():
		await place(fixtures[i])
		var order := ["full before", "corridor hidden", "running line hidden", "inner brick leaves hidden", "full after"]
		if i == 1:
			order = ["full before", "inner brick leaves hidden", "running line hidden", "corridor hidden", "full after"]
		for stage: String in order:
			var nodes: Array = groups.get(stage, [])
			for item: Node3D in nodes:
				item.hide()
			await frames(8)
			await measure(fixtures[i], 1, stage, 24)
			for item: Node3D in nodes:
				item.show()
	var report := {"source_groups":paths, "driver":RenderingServer.get_current_rendering_driver_name(), "adapter":RenderingServer.get_video_adapter_name(), "resolution":str(root.size), "camera_poses":poses, "results":rows}
	FileAccess.open(destination, FileAccess.WRITE).store_string(JSON.stringify(report))
	game.queue_free()
	for tick in 3:
		await process_frame
	timeline.queue_free()
	await process_frame
	quit(0)
