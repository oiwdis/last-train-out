import csv
import json
import math
import statistics
import zipfile
from pathlib import Path

work = Path('/tmp/lto4/medium118')
dest = work.parent/'evidence118'
suites = {}
rows = []
poses = {}
reference_pack = None
focus = ['Warehouse B', 'Locomotive cab', 'Passenger car', 'Inside dangerous fog']
order = ('reference-first', 'candidate-first', 'candidate-repeat', 'reference-repeat')

def percentile(numbers, probability):
    return sorted(numbers)[math.ceil(probability*len(numbers))-1]

def append(build, archive, filename, records, location, workload):
    vals = [v for r in records for v in r['frames_ms']]
    cutoff = percentile(vals, .95)
    tails = [t for r in records for v, t in zip(r['frames_ms'], r['timeline']) if v>=cutoff]
    mean = lambda key: statistics.fmean(r[key] for r in records)
    line = {'build':build,'workload':workload,'archive':archive,'raw_report':filename,'location':location,
        'frames':len(vals),'p50_ms':round(statistics.median(vals),4),'p95_ms':round(cutoff,4),
        'p99_ms':round(percentile(vals,.99),4),'worst_ms':round(max(vals),4),
        'above_16_67':sum(v>1000/60 for v in vals),'above_33_3':sum(v>33.3 for v in vals),
        'draw_calls':round(mean('draw_calls'),3),'primitives':round(mean('primitives'),3),'render_cpu_ms':round(mean('render_cpu_ms'),4),
        'texture_mib':round(mean('texture_bytes')/2**20,2),'slow_tail_sample_count':len(tails)}
    for key in ('render_bracket_ms','process_bracket_ms','physics_bracket_ms'):
        line['slow_tail_mean_'+key]=round(statistics.fmean(t[key] for t in tails),3)
    for key in ('draw','specialization','surface'):
        line[key+'_pipeline_changes']=sum(r['pipeline_delta'][key] for r in records)
    rows.append(line)

for build in ('111','115','117','118'):
    with zipfile.ZipFile(work.parent/('build'+build)/'native-metal-environment.zip') as z:
        manifest=json.loads(z.read('comparison.json'))
        original=manifest['packs']['reference']['sha256']
        if reference_pack is None:reference_pack=original
        assert original==reference_pack
        for a in order:
            filename=a+'.json'
            j=json.loads(z.read(filename))
            assert j['driver']=='metal' and j['resolution']=='(960, 540)' and (j['samples'],j['warmup'])==(180,48)
            these=[q for q in j['camera_poses'] if q['preset']==1]
            if not poses:poses=these
            assert poses==these
            source=[t for t in j['results'] if (t['preset'],t['stage'])==('Medium','steady')]
            assert len(source)==16
            for name in focus+['All 16 views']:
                keep=source if name=='All 16 views' else [q for q in source if q['location']==name]
                append(build,'native-metal-environment',filename,keep,name,'matched world')

with zipfile.ZipFile(work.parent/'build118/metal-library-policy.zip') as z:
    for filename in ['immediate-matrix.json','lazy-matrix.json']:
        j=json.loads(z.read(filename))
        assert j['driver']=='metal' and j['samples']==180 and j['warmup']==60
        for name in focus:
            group=[q for q in j['results'] if (q['preset'],q['stage'],q['location'])==('Medium','steady',name)]
            assert len(group)==1
            append('118','metal-library-policy',filename,group,name,'library policy')
with (dest/'medium-interiors.csv').open('w') as f:
    writer=csv.DictWriter(f,fieldnames=rows[0].keys(),lineterminator='\n')
    writer.writeheader()
    writer.writerows(rows)
for n in focus+['All 16 views']:
    for b in ['117','118']:
        print(n,b,[(v['raw_report'],v['p95_ms'],v['above_16_67'],v['above_33_3'],v['slow_tail_mean_render_bracket_ms'],v['slow_tail_mean_process_bracket_ms'],v['slow_tail_mean_physics_bracket_ms']) for v in rows if v['build']==b and v['location']==n])
