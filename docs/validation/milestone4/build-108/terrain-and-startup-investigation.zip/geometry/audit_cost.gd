extends SceneTree
func _initialize() -> void: assess.call_deferred()
func assess() -> void:
	var started := Time.get_ticks_usec()
	var scene := load("res://resources/journey/rail_corridor.scn") as PackedScene
	var loaded := Time.get_ticks_usec()
	var corridor := scene.instantiate() as Node3D
	var inst := Time.get_ticks_usec()
	root.add_child(corridor)
	var attached := Time.get_ticks_usec()
	var materials := {}
	var counts := {}
	for item in corridor.find_children("*","MeshInstance3D",true,false):
		var mesh: Mesh = item.mesh
		var category := str(item.get_parent().name) if not str(item.get_parent().name).begins_with('Track_') else str(item.name)
		if not counts.has(category):counts[category]=[0,0]
		counts[category][0]+=1
		for index in mesh.get_surface_count():
			materials[item.get_active_material(index)]=true
			if mesh is ArrayMesh: counts[category][1]+=mesh.surface_get_array_index_len(index)/3
	print('corridor milliseconds load/instantiate/in_world ', [(loaded-started)/1e3,(inst-loaded)/1e3,(attached-inst)/1e3], ' counts ',counts,' materials ',materials.size(), ' nodes ',corridor.find_children('*','',true,false).size())
	corridor.free()
	var def := JourneyDefinition.new();var route := def.build_route()
	for native in ['ashford','blackwater']:
		var station := JourneyStation.new();station.station_id=native
		station.free()
	quit()
