import io,json,zipfile
from pathlib import Path
from PIL import Image
import numpy as np
tmp=Path('/tmp/lto4');src=tmp/'floor/junction-light';repo=Path('/workspace/last-train-out-m35');out=repo/'docs/validation/milestone4/ashford-floors'
def read(path):
    return np.asarray(Image.open(path).convert('RGB'))
ordinary=read(src/'ordinary.png')
coords=[(x,y) for x in range(536,606) for y in range(round(319+(x-535)*.13)-5,round(319+(x-535)*.13)+6) if ordinary[y,x].min()>155]
assert len(coords)==150
def region(im):return np.array([im[y,x] for x,y in coords])
samples={}
for f in src.glob('*.png'):
    im=region(read(f));samples[f.stem]={'mean_rgb':[round(float(v),2) for v in im.mean(axis=0)],'max_absolute_change_from_ordinary':int(np.abs(im.astype('int16')-region(ordinary)).max())}
rays=json.loads((src/'rays.json').read_text());assert all(r['shape'].endswith('/FloorSlab') and r['sun_blocker'] for r in rays['rays'][:4]);assert np.max(np.abs(np.array(samples['shadow_bias_control']['mean_rgb'])-samples['directional_off']['mean_rgb']))<1
rec={'source':'86007236d795713a9271dec69977ddde5e9441d5','renderer':'Godot 4.5.1 software Vulkan High at 960 x 540','native_reference':'PR 6 build 104 and build 117, same native Metal view','region':'150 pixels above 155 in every channel in the measured strip adjacent to the back wall in the ordinary software screen. Same coordinates in all six controls.','controls':samples}
(src/'pixels.json').write_text(json.dumps(rec,indent=2)+'\n')
with zipfile.ZipFile(out/'wall-light-comparison.zip','w',zipfile.ZIP_DEFLATED,compresslevel=5) as archive:
    for name in ('ordinary.png','directional_off.png','door_casting.png','floor_marker.png','extending_wall_below_floor.png','shadow_bias_control.png','rays.json','pixels.json','inspect.gd','assess.py','engine.log'):archive.write(src/name,'software-vulkan/'+name)
    with zipfile.ZipFile(tmp/'build117/native-metal-environment.zip') as actual:
        for variant in ('reference','candidate'):
            n=f'{variant}-images/2-ashford_workshop.png';archive.writestr('native-metal/'+n,actual.read(n))
p=out/'README.md';text=p.read_text();title='## Narrow highlight behind the bench'
if title not in text:p.write_text(text+f"""
{title}

The native High views of the integration and build 117 both show a thin blue-white strip where the workshop floor meets the far wall. Pixel-matched collider rays through four points on that strip hit the solid floor. A second ray towards the directional light hit the wall in every case. Marking the floor magenta colored the entire strip. Closing the doorway with a temporary shadow caster or extending the wall 25 cm below the slab preserved the highlight. Disabling the directional light or zeroing its shadow bias and normal bias removed it. Across the same 150 bright pixels, mean RGB changed from (185, 199, 219) to (99, 102, 108). The narrow highlight is a directional-shadow bias artifact. Both the integration and the overhauled scene retain their authored shadow settings. The repaired outdoor pavement covered a much larger part of the floor and has its own geometry and visibility controls above. [Two native frames, six controlled renders, original rays and pixel values](wall-light-comparison.zip)
""")
print(samples,flush=True)
