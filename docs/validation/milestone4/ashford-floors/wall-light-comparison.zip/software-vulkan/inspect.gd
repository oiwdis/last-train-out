extends "res://scripts/diagnostics/integration_benchmark.gd"

func run() -> void:
	suite = "environment"
	output_dir = "/tmp/lto4/floor/junction-light"
	game = load("res://scenes/missions/harlow_escape.tscn").instantiate()
	root.add_child(game)
	await ready_render()
	journey = game.journey
	fog = game.fog_system
	game.player.input.scripted = true
	for actor: Node in [game.player, game.train, journey, fog, game.camera_rig]:
		actor.set_physics_process(false)
	game.camera_rig.exploration.set_process(false)
	eye = Camera3D.new()
	eye.fov = 78
	eye.near = 0.06
	eye.far = 350
	game.add_child(eye)
	eye.make_current()
	game.graphics.set_preset(2)
	await ready_render()
	await place("Ashford workshop")
	await frames(8)
	var building: StationBuilding = journey.stations[0].buildings[1]
	var floor_part := building.get_child(0) as BoxPart
	var sun := game.find_children("*","DirectionalLight3D",true,false)[0] as DirectionalLight3D
	var space := game.get_world_3d().direct_space_state
	var receipt := {"view":str(root.get_visible_rect().size),"width":str(root.size),"rays":[],"sun_world_axis":str(sun.global_basis.z),"sun_building_axis":str(building.global_basis.inverse()*sun.global_basis.z)}
	for px in [Vector2(540.5,319.5),Vector2(550.5,320.5),Vector2(565.5,322.5),Vector2(590.5,325.5),Vector2(565.5,329.5),Vector2(565.5,318.5)]:
		var uv: Vector2 = px * root.get_visible_rect().size / Vector2(960,540)
		var origin := eye.project_ray_origin(uv)
		var q := PhysicsRayQueryParameters3D.create(origin,origin+eye.project_ray_normal(uv)*50.,1)
		var hit := space.intersect_ray(q)
		var row := {"pixel":str(px),"hit":str(hit.get("position"))}
		if not hit.is_empty():
			var who: CollisionObject3D = hit.collider
			var target: Node = who.shape_owner_get_owner(who.shape_find_owner(hit.shape))
			row["shape"] = str(target.get_path())
			row["building_local_hit"] = str(building.to_local(hit.position))
			var to_sun: Vector3 = sun.global_basis.z.normalized()
			var start: Vector3 = hit.position+to_sun*.003
			var lit := space.intersect_ray(PhysicsRayQueryParameters3D.create(start,start+to_sun*30,1))
			row["sun_blocker"] = str(lit.collider.shape_owner_get_owner(lit.collider.shape_find_owner(lit.shape)).get_path()) if not lit.is_empty() else ""
		receipt.rays.append(row)
	FileAccess.open(output_dir+"/rays.json",FileAccess.WRITE).store_string(JSON.stringify(receipt,"  "))
	await capture("ordinary")
	sun.visible = false
	await capture("directional_off")
	sun.visible = true
	var door := MeshInstance3D.new()
	var door_mesh := BoxMesh.new()
	door_mesh.size = Vector3(2.7,building.dimensions.y,0.30)
	door.mesh = door_mesh
	door.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_SHADOWS_ONLY
	building.add_child(door)
	door.position = Vector3(0,building.dimensions.y/2,building.dimensions.z/2)
	await capture("door_casting")
	door.free()
	var marker := StandardMaterial3D.new()
	marker.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	marker.albedo_color = Color(1,0,1)
	floor_part.get_mesh_instance().material_override = marker
	await capture("floor_marker")
	floor_part.get_mesh_instance().material_override = null
	var originals := {}
	for i in [1,2,4]:
		var wall := building.get_child(i) as BoxPart
		var mesh_node := wall.get_mesh_instance()
		originals[mesh_node] = mesh_node.transform
		mesh_node.scale.y = (wall.size.y+.25)/wall.size.y
		mesh_node.position.y -= .125
	await capture("extending_wall_below_floor")
	for mesh_node: MeshInstance3D in originals:
		mesh_node.transform = originals[mesh_node]
	var original_bias := sun.shadow_normal_bias
	var original_depth := sun.shadow_bias
	sun.shadow_normal_bias = 0
	sun.shadow_bias = 0
	await capture("shadow_bias_control")
	sun.shadow_normal_bias = original_bias
	sun.shadow_bias = original_depth
	await DiagnosticSceneRetirement.release(game)
	quit()

func capture(label: String) -> void:
	await frames(8)
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(output_dir+"/"+label+".png")
	print("[wall diagnostic] ",label)
