import csv,json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import numpy as np
p=Path('/tmp/lto4/floor')
photos={};rows=[]
for preset in range(3):
 for location in ('ashford_workshop','ashford_fitter_bench'):
  pairs={}
  for surface in ('coplanar','raised'):
   f=p/f'{preset}-{location}-{surface}.png'
   if not f.is_file() or not (p/(f.stem+'_without_apron.png')).is_file():continue
   src=np.array(Image.open(f).convert('RGB'),dtype=np.int16);ref=np.array(Image.open(p/(f.stem+'_without_apron.png')).convert('RGB'),dtype=np.int16)
   assert src.shape==ref.shape==(540,960,3)
   diff=np.abs(src-ref)[432:530,30:930]
   pairs[surface]=round(100*np.mean(np.max(diff,axis=2)>8),3)
   photos[preset,location,surface]=f
  if len(pairs)==2:rows.append({'preset':['Low','Medium','High'][preset],'view':location,**pairs})
print(rows)
(p/'pixel-control.json').write_text(json.dumps({'adapter':'Linux Godot 4.5.1 Forward+ / llvmpipe','images':'960x540 real mission, same camera and preset per pair','floor_mask':'x=30..929, y=432..529. Fraction of pixels with any RGB channel changing by >8/255 when hiding only the apron mesh. Collider stays active; no post-processing of the actual screenshots.','values_percent':rows},indent=2)+'\n')
if len(photos)>=4 and (1,'ashford_workshop','raised') in photos:
 sheet=Image.new('RGB',(972,634),'#192628');draw=ImageDraw.Draw(sheet);font=ImageFont.truetype('DejaVuSans.ttf',15)
 for col,(s,title) in enumerate([('coplanar','Coplanar pavement and interior floor'),('raised','Raised floor and continuous threshold')]):
  draw.text((4+col*484,5),title,fill='white',font=font)
  for i,loc in enumerate(['ashford_workshop','ashford_fitter_bench']):
   if (1,loc,s) not in photos:continue
   draw.text((4+col*484,32+i*299),loc.replace('_',' ').title(),fill='#dcebdc',font=font)
   with Image.open(photos[1,loc,s]) as image:sheet.paste(image.convert('RGB').resize((480,270),Image.Resampling.LANCZOS),(4+484*col,55+i*299))
 sheet.save(p/'floor-comparison.jpg',quality=92)
