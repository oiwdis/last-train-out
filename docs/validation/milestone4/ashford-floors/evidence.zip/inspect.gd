extends "res://scripts/diagnostics/integration_benchmark.gd"

func run() -> void:
	suite = "environment"
	output_dir = "/tmp/lto4/floor"
	game = load("res://scenes/missions/harlow_escape.tscn").instantiate()
	root.add_child(game)
	await ready_render()
	journey = game.journey
	fog = game.fog_system
	game.player.input.scripted = true
	for actor: Node in [game.player, game.train, journey, fog, game.camera_rig]:
		actor.set_physics_process(false)
	game.camera_rig.exploration.set_process(false)
	eye = Camera3D.new()
	eye.fov = 78
	eye.near = 0.06
	eye.far = 350
	game.add_child(eye)
	eye.make_current()
	var station: JourneyStation = journey.stations[0]
	var apron: BoxPart = station.site.get_node("FreightApron")
	for preset in [1, 2, 0]:
		game.graphics.set_preset(preset)
		await ready_render()
		for location in ["Ashford workshop", "Ashford fitter bench"]:
			await place(location)
			for treatment in ["coplanar", "coplanar_without_apron", "raised_without_apron", "raised"]:
				for building in station.buildings:
					building.position.y = 0.04 if treatment.begins_with("raised") else 0.0
				apron.get_mesh_instance().visible = not treatment.ends_with("without_apron")
				await frames(8)
				await RenderingServer.frame_post_draw
				var file := "%d-%s-%s.png" % [preset, location.to_snake_case(), treatment]
				root.get_texture().get_image().save_png(output_dir.path_join(file))
				print("[floor photo] ", file)
	await DiagnosticSceneRetirement.release(game)
	quit()
