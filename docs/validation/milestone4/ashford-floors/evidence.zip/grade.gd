extends SceneTree
func _initialize() -> void:
	inspect.call_deferred()
func inspect() -> void:
	var station: JourneyStation = load("res://scenes/station/ashford_depot.tscn").instantiate()
	root.add_child(station)
	for i in 5: await physics_frame
	var apron: BoxPart = station.site.get_child(0)
	var yard_mesh := apron.get_mesh_instance()
	var yard_top := (yard_mesh.global_transform * yard_mesh.mesh.get_aabb()).end.y
	var values := []
	for building in station.buildings:
		var floor_part := building.get_child(0) as BoxPart
		var mesh := floor_part.get_mesh_instance()
		var slab_top := (mesh.global_transform * mesh.mesh.get_aabb()).end.y
		var shape := floor_part.shape as BoxShape3D
		var point := building.to_global(Vector3(2.,0.,1.))
		var query := PhysicsRayQueryParameters3D.create(point+Vector3.UP,point-Vector3.UP,1)
		var hit := station.get_world_3d().direct_space_state.intersect_ray(query)
		values.append({"building":building.title, "rendered_floor_y":slab_top, "rendered_pavement_y":yard_top,
			"gap_m":slab_top-yard_top,"floor_collision_top":floor_part.global_position.y+shape.size.y*.5,
			"first_collider":hit.collider.name if not hit.is_empty() else "none"})
	print("[floor geometry] ",JSON.stringify(values))
	station.free()
	quit()
